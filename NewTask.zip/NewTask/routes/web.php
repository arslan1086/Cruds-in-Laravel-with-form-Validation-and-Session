<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MemberListController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


// Login Form
// Route::view("login",'login');
Route::view("MemberList",'MemberList');
// for logout
Route::get('/logout', function () {
    if(session()->has('user'))
    {
        session()->pull('user',null);
    }
    return redirect('login');
});

// for login
Route::get('/login', function () {
    if(session()->has('user'))
    {
        return redirect('MemberList');
    }
    return view('login');
});
Route::post("MemberList",[MemberListController::class,'login']); 




Route::post("add",[MemberListController::class,'addData']); 
// Route::post("add",[NewController::class,'getData']);
Route::view("add",'addmember');


// Show Data from Database
Route::get("MemberList",[MemberListController::class,'showData']); 

// Delete Row
Route::get("delete/{id}",[MemberListController::class,'delete']); 


// Edit Row
Route::get('edit/{id}',[MemberListController::class,'show']); 
Route::post('update',[MemberListController::class,'update'])->name('update'); 
