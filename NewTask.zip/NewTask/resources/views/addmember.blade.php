<h1>Add Member</h1>
<!-- @if($errors->any())
@foreach ($errors->all() as $err)
<li>{{$err}}</li>
@endforeach
@endif -->
<form action="" method="POST">
  @csrf
  <!-- <input type="hidden" name="_token" placeholder="Enter your name" value="{{csrf_token()}}" /><br><br> -->
  <input type="text" name="name" placeholder="Enter your name" value="{{old('name')}}" /><br>
  <span style="color:red;">@error('name'){{$message}}@enderror</span><br>
  <input type="email" name="email" placeholder="Enter your Email" value="{{old('email')}}"/><br>
  <span style="color:red;">@error('email'){{$message}}@enderror</span><br>
  <input type="text" name="address" placeholder="Enter your Address" value="{{old('address')}}"/><br>
  <span style="color:red;">@error('address'){{$message}}@enderror</span><br>

  <button type="submit">Submit</button>
</form>
