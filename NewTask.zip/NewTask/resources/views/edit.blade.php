<h1>Add Member</h1>

<form action="{{route('update')}}" method="POST">
  @csrf
  <!-- <input type="hidden" name="_token" placeholder="Enter your name" value="{{csrf_token()}}" /><br><br> -->
  <input type="hidden" name="id" value="{{$data['id']}}" /><br>
  <input type="text" name="name" value="{{$data['name']}}" /><br>
  <span style="color:red;">@error('name'){{$message}}@enderror</span><br>
  <input type="email" name="email" value="{{$data['email']}}"/><br> 
  <span style="color:red;">@error('email'){{$message}}@enderror</span><br>
  <input type="text" name="address" value="{{$data['address']}}"/><br>
  <span style="color:red;">@error('address'){{$message}}@enderror</span><br>


  <button type="submit">Update</button>
</form>