<h1>Login Form</h1>
<!-- @if($errors->any())
@foreach ($errors->all() as $err)
<li>{{$err}}</li>
@endforeach
@endif -->
<form action="/MemberList" method="POST">
  @csrf
  <!-- <input type="hidden" name="_token" placeholder="Enter your name" value="{{csrf_token()}}" /><br><br> -->

  <input type="text" name="user" placeholder="Enter your Name"/><br>
  <input type="password" name="password" placeholder="Enter your Password"/><br>

  <button type="submit">Login</button>


</form>
