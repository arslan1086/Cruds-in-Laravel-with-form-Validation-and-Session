<h1>Login Form</h1>
<!-- <?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($err); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?> -->
<form action="/MemberList" method="POST">
  <?php echo csrf_field(); ?>
  <!-- <input type="hidden" name="_token" placeholder="Enter your name" value="<?php echo e(csrf_token()); ?>" /><br><br> -->

  <input type="text" name="user" placeholder="Enter your Name"/><br>
  <input type="password" name="password" placeholder="Enter your Password"/><br>

  <button type="submit">Login</button>


</form>
<?php /**PATH C:\Users\Arslan Khan\Desktop\NewTask\resources\views/login.blade.php ENDPATH**/ ?>