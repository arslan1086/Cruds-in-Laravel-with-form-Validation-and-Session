<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">




<div class="container"><br><br>
    <a class="btn btn-primary" href="/add" role="button">Add Members</a>
    <a class="btn btn-primary" href="/logout" role="button">Logout</a>
    <h1 style="text-align:center;">Member List</h1>

    <table class="table table-bordered ">
    <thead>
        <tr>
        <th scope="col">ID</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Address</th>
        <th colspan="2" scope="col" style="text-align:center;">Operations</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($member['id']); ?></td>
        <td><?php echo e($member['name']); ?></td>
        <td><?php echo e($member['email']); ?></td>
        <td><?php echo e($member['address']); ?></td>
        <td><a href=<?php echo e("delete/".$member['id']); ?>>Delete</a></td>
        <td><a href=<?php echo e("edit/".$member['id']); ?>>Update</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </tbody>
    </table>
</div>




<?php /**PATH C:\Users\Arslan Khan\Desktop\NewTask\resources\views/memberlist.blade.php ENDPATH**/ ?>