<h1>Add Member</h1>
<!-- <?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($err); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?> -->
<form action="" method="POST">
  <?php echo csrf_field(); ?>
  <!-- <input type="hidden" name="_token" placeholder="Enter your name" value="<?php echo e(csrf_token()); ?>" /><br><br> -->
  <input type="text" name="name" placeholder="Enter your name" value="<?php echo e(old('name')); ?>" /><br>
  <span style="color:red;"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
  <input type="email" name="email" placeholder="Enter your Email" value="<?php echo e(old('email')); ?>"/><br>
  <span style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
  <input type="text" name="address" placeholder="Enter your Address" value="<?php echo e(old('address')); ?>"/><br>
  <span style="color:red;"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>

  <button type="submit">Submit</button>
</form>
<?php /**PATH C:\Users\Arslan Khan\Desktop\NewTask\resources\views/addmember.blade.php ENDPATH**/ ?>