<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Member;

class MemberListController extends Controller
{


    function login(Request $req)
    {
        $data = $req->input('user');
        $req->session()->put('user', $data);

        // to check that the data show in next page that we enter in login form
        // echo session('user');
        // echo session('password');

        return redirect('MemberList');
    }



    function addData(Request $req)
    {
        $req->validate(
            [
                'name' => 'required | min:5 | max:255',
                'email' => 'required | email',
                'address' => 'required | min:5 | max:255',
                'password' => 'required',
            ]
        );
        $member = new Member;
        $member->name=$req->name;
        $member->email=$req->email;
        $member->address=$req->address;
        $member->save();
        return redirect('MemberList');
    }










    // Show or Fetch data from database:
    function showData()
    {
        $data = Member::all();
        return view("memberlist",['members'=>$data]);
    }



    // Delete data in the table and database:
    function delete($id)
    {
        $data = Member::find($id);
        $data->delete();
        return redirect('MemberList');
    }





    // Show data in the field when we update Function
    function show($id)
    {
        $data = Member::find($id);
        return view('edit',['data'=>$data]);
        // return redirect('MemberList');
    }





    // Update Function
    function update(Request $req)
    {
        $data=Member::find($req->id);
        $data->name=$req->name;
        $data->email=$req->email;
        $data->address=$req->address;
        $data->save();
        return redirect('MemberList');
    }
}
    